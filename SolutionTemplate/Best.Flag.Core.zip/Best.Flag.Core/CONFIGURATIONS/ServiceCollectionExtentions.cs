﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Configurations
{
    public static class ServiceCollectionExtentions
    {
        public static void MapUseCases(this IServiceCollection service)
        {

        }

        public static void MapValidations(this IServiceCollection service)
        {

        }
    }
}